#!/bin/sh 


echo "install ... ..."

cp -rf  ./rabbitd  /etc/init.d/
chmod +x /etc/init.d/rabbitd
chkconfig --add rabbitd
chkconfig --level 2345 rabbitd on

echo "finish"