echo "export PATH=$PATH:/usr/local/erlang/bin" >> /etc/profile
source /etc/profile
