#!/bin/sh 


echo "install ... ..."

cp -rf  ./fdfsd_tracker  ./fdfsd

cp -rf  ./fdfsd  /etc/init.d/
chmod +x /etc/init.d/fdfsd
chkconfig --add fdfsd
chkconfig --level 2345 fdfsd on

echo "finish"