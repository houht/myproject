#!/bin/sh 


echo "install nginx... ..."


cp -rf nginx_tracker.conf nginx.conf 

read  -p   "Enter Storage IP, Delimiter [;]  : "  ips

var=${ips//;/ } 
for ip in $var
    do
        tmp="\tserver $ip;\n"
        str="$str$tmp"
    done

sed -i "s#myServerIp#$str#g"  nginx.conf

cp -rf  ./nginxd  /etc/init.d/
chmod +x /etc/init.d/nginxd
chkconfig --add nginxd
chkconfig --level 2345 nginxd on

echo "nginx finish"
