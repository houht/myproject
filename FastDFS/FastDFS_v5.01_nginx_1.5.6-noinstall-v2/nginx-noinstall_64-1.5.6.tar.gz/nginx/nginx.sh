#!/bin/sh 


echo "install ... ..."

cp -rf  ./nginxd  /etc/init.d/
chmod +x /etc/init.d/nginxd
chkconfig --add nginxd
chkconfig --level 2345 nginxd on

echo "finish"